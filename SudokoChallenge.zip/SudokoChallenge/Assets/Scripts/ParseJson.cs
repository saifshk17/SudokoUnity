﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class ParseJson : MonoBehaviour {
	public string path;

	public string jsonString;


	public InputJson exe = new InputJson();

	// Use this for initialization
	void Start () {
		path = Application.streamingAssetsPath + "/Sudoku.json";
		jsonString = File.ReadAllText(path);
		exe = JsonUtility.FromJson<InputJson>(jsonString);

		
	}

	// Update is called once per frame
	void Update () {
		Debug.Log(" " +exe.ToString());
	}
}
