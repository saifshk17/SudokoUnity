﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;


public class ExtractJsonData : MonoBehaviour
{
	public Text text;
	
	int i = 0;
	private ParseJson parser;


	// Use this for initialization
	void Start()
	{

		
		parser = (ParseJson)FindObjectOfType(typeof(ParseJson));

		StartCoroutine(Reading());

	
	}



	IEnumerator Reading()
	{
	//	for (int i = 0; i <= (parser.exe.Grid_1.Length); i++)
		{
			//	Debug.Log("length " + parser.exe.Location.Length);
			WWW load = new WWW("file:///" + parser.exe);
			yield return load;
			
		}

	
	}

	



	void LateUpdate()
	{

	
	}



}
